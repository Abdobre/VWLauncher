package com.carlauncher

import android.service.notification.NotificationListenerService

/** Needed only so the launcher may read the active media session (title/artist). */
class MediaListener : NotificationListenerService()
