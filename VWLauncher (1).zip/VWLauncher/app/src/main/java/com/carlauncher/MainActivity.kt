package com.carlauncher

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.media.AudioManager
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.ui.graphics.graphicsLayer
import android.os.Build
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.edit
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlinx.coroutines.delay
import java.io.File
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

// VW-inspired palette (no logos/trademarks included)
val VwDark = Color(0xFF001E50)
val VwNight = Color(0xFF000F2B)
val VwBlue = Color(0xFF00B0F0)
val VwCard = Color(0xFF0A2C6B)

class Palette(val bg1: Color, val bg2: Color, val card: Color, val text: Color, val accent: Color)
val Night = Palette(VwDark, VwNight, VwCard, Color.White, VwBlue)
val Day = Palette(Color(0xFFF2F5FA), Color(0xFFDCE5F2), Color.White, VwDark, Color(0xFF0072B8))

@Composable
fun Palette.animated(): Palette {
    val t = tween<Color>(600)
    return Palette(animateColorAsState(bg1, t, label = "b1").value, animateColorAsState(bg2, t, label = "b2").value,
        animateColorAsState(card, t, label = "c").value, animateColorAsState(text, t, label = "t").value,
        animateColorAsState(accent, t, label = "a").value)
}

fun Modifier.glass(p: Palette, r: Int = 20): Modifier {
    val sh = RoundedCornerShape(r.dp)
    return this.clip(sh).background(p.card.copy(alpha = .88f)).border(1.dp, p.accent.copy(alpha = .22f), sh)
}

@Composable
fun Modifier.pressScale(src: MutableInteractionSource): Modifier {
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (pressed) .94f else 1f, tween(120), label = "s")
    return this.graphicsLayer { scaleX = sc; scaleY = sc }
}

data class AppItem(val label: String, val pkg: String, val icon: ImageBitmap)

class MainActivity : ComponentActivity() {
    private var apps by mutableStateOf(emptyList<AppItem>())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = VwBlue)) { Home(apps, ::open, ::quick) }
        }
    }

    override fun onResume() { super.onResume(); apps = loadApps() }

    private fun loadApps(): List<AppItem> {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(i, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map { AppItem(it.loadLabel(packageManager).toString(), it.activityInfo.packageName,
                it.loadIcon(packageManager).toBitmap(128, 128).asImageBitmap()) }
            .sortedBy { it.label.lowercase() }
    }

    private fun open(pkg: String) { packageManager.getLaunchIntentForPackage(pkg)?.let { startActivity(it) } }

    private fun quick(kind: String) {
        val intent = when (kind) {
            "nav" -> Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q="))
            "music" -> Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MUSIC)
            "phone" -> Intent(Intent.ACTION_DIAL)
            "wifi" -> if (Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY) else Intent(Settings.ACTION_WIFI_SETTINGS)
            "bt" -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
            "notif" -> Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
            else -> Intent(Settings.ACTION_SETTINGS)
        }
        runCatching { startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }

    @Deprecated("Launcher: ignore back") override fun onBackPressed() {}
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Home(apps: List<AppItem>, onOpen: (String) -> Unit, onQuick: (String) -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("launcher", Context.MODE_PRIVATE) }
    val wallFile = remember { File(ctx.filesDir, "wallpaper.jpg") }

    var now by remember { mutableStateOf(LocalDateTime.now()) }
    var query by remember { mutableStateOf("") }
    var mode by remember { mutableStateOf(prefs.getInt("mode", 0)) } // 0 auto, 1 day, 2 night
    var favs by remember { mutableStateOf(prefs.getStringSet("favs", emptySet())!!.toSet()) }
    var wall by remember { mutableStateOf<ImageBitmap?>(if (wallFile.exists()) BitmapFactory.decodeFile(wallFile.path)?.asImageBitmap() else null) }
    var title by remember { mutableStateOf<String?>(null) }
    var playing by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        val msm = ctx.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
        while (true) {
            now = LocalDateTime.now()
            try {
                val c = msm.getActiveSessions(ComponentName(ctx, MediaListener::class.java)).firstOrNull()
                val m = c?.metadata
                title = m?.getString(android.media.MediaMetadata.METADATA_KEY_TITLE)?.let { t ->
                    val a = m.getString(android.media.MediaMetadata.METADATA_KEY_ARTIST); if (a.isNullOrBlank()) t else "$t — $a" }
                playing = c?.playbackState?.state == PlaybackState.STATE_PLAYING
            } catch (e: SecurityException) { title = null }
            delay(1000)
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri ?: return@rememberLauncherForActivityResult
        runCatching {
            val bmp = ctx.contentResolver.openInputStream(uri)!!.use {
                BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = 2 }) }!!
            wallFile.outputStream().use { bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 90, it) }
            wall = bmp.asImageBitmap()
        }
    }

    val night = mode == 2 || (mode == 0 && (now.hour >= 19 || now.hour < 6))
    val p = (if (night || wall != null) Night else Day).animated()
    val shown = apps.filter { it.label.contains(query, true) }
    val dock = favs.mapNotNull { f -> apps.firstOrNull { it.pkg == f } }

    val am = remember { ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    var vol by remember { mutableStateOf(am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()) }

    fun key(code: Int) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(p.bg1, p.bg2)))) {
        wall?.let {
            Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            Box(Modifier.fillMaxSize().background(Color(0x99000F2B)))
        }
        Row(Modifier.fillMaxSize().padding(24.dp)) {
            Column(Modifier.width(320.dp).fillMaxHeight().verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text(now.format(DateTimeFormatter.ofPattern("HH:mm")), fontSize = 72.sp, fontWeight = FontWeight.Light, color = p.text)
                Text(now.format(DateTimeFormatter.ofPattern("EEEE, d MMMM")), fontSize = 20.sp, color = p.accent)
                // Media widget
                Column(Modifier.fillMaxWidth().glass(p).padding(16.dp)) {
                    Text(title ?: "Enable now playing", color = p.text, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.fillMaxWidth().clickable(enabled = title == null) { onQuick("notif") })
                    Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                        Text("⏮", fontSize = 32.sp, color = p.accent, modifier = Modifier.clickable { key(KeyEvent.KEYCODE_MEDIA_PREVIOUS) }.padding(8.dp))
                        Text(if (playing) "⏸" else "▶", fontSize = 32.sp, color = p.accent, modifier = Modifier.clickable { key(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) }.padding(8.dp))
                        Text("⏭", fontSize = 32.sp, color = p.accent, modifier = Modifier.clickable { key(KeyEvent.KEYCODE_MEDIA_NEXT) }.padding(8.dp))
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Tile("Maps", Icons.Filled.Place, p, Modifier.weight(1f)) { onQuick("nav") }
                    Tile("Music", Icons.Filled.PlayArrow, p, Modifier.weight(1f)) { onQuick("music") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Tile("Phone", Icons.Filled.Phone, p, Modifier.weight(1f)) { onQuick("phone") }
                    Tile("Settings", Icons.Filled.Settings, p, Modifier.weight(1f)) { onQuick("settings") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Chip("Wi‑Fi", p, Modifier.weight(1f)) { onQuick("wifi") }
                    Chip("Bluetooth", p, Modifier.weight(1f)) { onQuick("bt") }
                }
                Row(Modifier.fillMaxWidth().glass(p).padding(horizontal = 16.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("🔈", fontSize = 20.sp)
                    Slider(vol, { vol = it; am.setStreamVolume(AudioManager.STREAM_MUSIC, it.toInt(), 0) },
                        Modifier.weight(1f).padding(start = 8.dp), valueRange = 0f..am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).toFloat(),
                        colors = SliderDefaults.colors(thumbColor = p.accent, activeTrackColor = p.accent))
                }
            }
            Spacer(Modifier.width(24.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(query, { query = it }, Modifier.weight(1f), singleLine = true,
                        placeholder = { Text("Search apps") }, leadingIcon = { Icon(Icons.Filled.Search, null) },
                        shape = RoundedCornerShape(28.dp),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = p.text, unfocusedTextColor = p.text))
                    // Day / Night / Auto
                    Box(Modifier.size(56.dp).glass(p, 16)
                        .clickable { mode = (mode + 1) % 3; prefs.edit { putInt("mode", mode) } },
                        contentAlignment = Alignment.Center) {
                        Text(listOf("A", "☀", "☾")[mode], color = p.accent, fontSize = 24.sp)
                    }
                    // Wallpaper: tap = choose, long-press = reset
                    Box(Modifier.size(56.dp).glass(p, 16)
                        .combinedClickable(onClick = { picker.launch("image/*") },
                            onLongClick = { wallFile.delete(); wall = null }),
                        contentAlignment = Alignment.Center) {
                        Icon(Icons.Filled.Edit, null, tint = p.accent)
                    }
                }
                Spacer(Modifier.height(16.dp))
                LazyVerticalGrid(GridCells.Adaptive(120.dp), Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(shown, key = { it.pkg }) { a ->
                        AppCell(a, a.pkg in favs, p, onOpen) {
                            favs = if (a.pkg in favs) favs - a.pkg else favs + a.pkg
                            prefs.edit { putStringSet("favs", favs) }
                        }
                    }
                }
                // Favorites dock (long-press an app to add/remove)
                Row(Modifier.fillMaxWidth().padding(top = 12.dp).glass(p, 24).padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (dock.isEmpty()) Text("Long-press an app to pin it here", color = p.text.copy(alpha = .6f), fontSize = 14.sp)
                    dock.forEach { a ->
                        Image(a.icon, a.label, Modifier.size(56.dp).clip(RoundedCornerShape(14.dp)).clickable { onOpen(a.pkg) })
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppCell(a: AppItem, fav: Boolean, p: Palette, onOpen: (String) -> Unit, onToggleFav: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    Column(Modifier.pressScale(src).glass(p)
        .combinedClickable(interactionSource = src, indication = null, onClick = { onOpen(a.pkg) }, onLongClick = onToggleFav)
        .padding(16.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Box { Image(a.icon, a.label, Modifier.size(72.dp).clip(RoundedCornerShape(16.dp)))
            if (fav) Icon(Icons.Filled.Star, null, tint = p.accent, modifier = Modifier.size(20.dp).align(Alignment.TopEnd)) }
        Spacer(Modifier.height(10.dp))
        Text(a.label, color = p.text, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun Tile(label: String, icon: ImageVector, p: Palette, modifier: Modifier, onClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    Column(modifier.height(88.dp).pressScale(src).glass(p).clickable(src, null, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(icon, null, tint = p.accent, modifier = Modifier.size(30.dp))
        Text(label, color = p.text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun Chip(label: String, p: Palette, modifier: Modifier, onClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    Box(modifier.height(52.dp).pressScale(src).glass(p, 26).clickable(src, null, onClick = onClick), contentAlignment = Alignment.Center) {
        Text(label, color = p.text, fontSize = 15.sp)
    }
}
